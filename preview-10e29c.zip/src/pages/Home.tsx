import { useState } from "react";
import { ArrowDown, ArrowRight, ArrowUpRight, Menu, X } from "lucide-react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";

const fallbackContent = {
  announcement: "Ideas for Earth. Objects for the movement.",
  heroTitle: "Make Earth great again",
  heroText:
    "MEGA Party Worldwide is an independent ideas house for truth seekers and independent thinkers. We promote free speech and open discussions to solve the problems of our complex world. Our mission is to awaken the divinity within each of our community members so they may reclaim their power to shape our world. We promote the African philosophy of Ubuntu, meaning “I am because we are,” and the harmonious principle of Ma’at.",
  bookUrl: "https://www.lulu.com/shop/samuel-immanuel/uncommon-sense/paperback/product-456n9r6.html?q=uncommon+sense&page=1&pageSize=4",
  youtubeUrl: "https://www.youtube.com/@samuelimmanuel13",
  farcasterUrl: "https://farcaster.xyz/samuelimmanuel",
  youtubeTitle: "Watch the ideas in motion",
};

const values = [
  {
    title: "Earth is our Mother",
    text: "We choose regeneration over extraction, stewardship over short term profit and a future where humanity lives in harmony with nature.",
  },
  {
    title: "Power to the People",
    text: "Centralization breeds corruption and censorship. Decentralization is incorruptible and censorship resistant. Centralization keeps money and power in the hands of the elites. Decentralization puts money and power into the hands of the people.",
  },
  {
    title: "Inner peace creates outer peace",
    text: "The hermetic principle of as above so below highlights the inseparable connection between human consciousness and the unfolding universe. We have the power to create our reality with our thoughts, feelings and actions. With love and knowledge, we can conquer chaos in order to create lasting peace.",
  },
  {
    title: "Question everything, embody the truth",
    text: "Truth, as depicted in the Essene Gospels of Peace, is not a single revelation but a harmony achieved through three interwoven paths. These paths are communion with the Earthly Mother, communion with the Heavenly Father, and communion with the Sacred Stream of Life that flows through all beings. These paths invite the seeker to align the body with nature, the mind with divine wisdom, and the spirit with the unity of all creation.",
  },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const siteQuery = trpc.content.site.useQuery(undefined, { retry: 1 });
  const updatesQuery = trpc.content.updates.useQuery(undefined, { retry: 1 });
  const content = siteQuery.data ?? fallbackContent;
  const updates = updatesQuery.data ?? [];
  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <a className="skip-link" href="#main">Skip to content</a>
      <div className="announcement" aria-label="Announcement">
        <div className="marquee-track">
          {[0, 1].map((copy) => (
            <div className="marquee-copy" key={copy} aria-hidden={copy === 1}>
              <span>Know yourself</span><span className="ribbon-ankh" aria-hidden="true">☥</span><span>Be true to yourself</span><span className="ribbon-ankh" aria-hidden="true">☥</span><span>Act according to your truth</span><span className="ribbon-ankh" aria-hidden="true">☥</span>
            </div>
          ))}
        </div>
      </div>

      <header className="site-header">
        <a href="#top" className="brand-lockup" aria-label="MEGA Party home" onClick={closeMenu}>
          <img src="/images/earth-mark.png" alt="" />
          <span>MEGA PARTY WORLDWIDE</span>
        </a>
        <nav className="desktop-nav" aria-label="Main navigation">
          <a href="#about">About</a>
          <a href="#book">Uncommon Sense</a>
          <a href="#objects">Shop</a>
          <a href="#watch">YouTube</a>
        </nav>
        <a className="header-cta" href="#book">Explore the book <ArrowUpRight size={17} /></a>
        <button className="menu-toggle" type="button" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X /> : <Menu />}
        </button>
      </header>

      {menuOpen && (
        <nav className="mobile-nav" aria-label="Mobile navigation">
          <a href="#about" onClick={closeMenu}>About <ArrowRight /></a>
          <a href="#book" onClick={closeMenu}>Uncommon Sense <ArrowRight /></a>
          <a href="#objects" onClick={closeMenu}>Shop <ArrowRight /></a>
          <a href="#watch" onClick={closeMenu}>YouTube <ArrowRight /></a>
          <a href={content.farcasterUrl} target="_blank" rel="noreferrer" onClick={closeMenu}>Farcaster <ArrowRight /></a>
          <Link to="/studio" onClick={closeMenu}>Studio <ArrowRight /></Link>
        </nav>
      )}

      <main id="main">
        <section className="hero" id="top">
          <div className="hero-lines" aria-hidden="true"><i /><i /><i /><i /><i /></div>
          <div className="hero-topline"><span>AN INDEPENDENT IDEAS HOUSE</span><span>ESTABLISHED 2026</span></div>
          <img className="hero-logo" src="/images/mega-party-green.png" alt="MEGA Party — a green Earth sprouting new leaves" />
          <div className="hero-bottom">
            <h1>{content.heroTitle}</h1>
            <div className="hero-intro">
              <p>{content.heroText}</p>
              <a className="text-link" href="#about">Discover the movement <ArrowDown size={18} /></a>
            </div>
          </div>
        </section>

        <section className="manifesto section-grid" id="about">
          <div className="section-aside"><span>OUR POSITION</span><span>MEGA</span></div>
          <div className="manifesto-content">
            <p className="display-statement">A different kind of party where everyone is invited</p>
            <div className="manifesto-copy">
              <p>MEGA Party Worldwide invites everyone to look within for answers to the problems of our modern world. We offer practical guidance based on spiritual lessons presented in Samuel Immanuel’s book Uncommon Sense. Our mission is to inspire collective action for the restoration and regeneration of our Mother Earth.</p>
            </div>
          </div>
        </section>

        <section className="values-section">
          <div className="values-heading"><span>OUR VALUES</span><h2>Principles for a New Earth</h2></div>
          <div className="values-list">
            {values.map((value, index) => (
              <article className="value-row" key={value.title}>
                <span className="value-index">0{index + 1}</span>
                <h3>{value.title}</h3>
                <p>{value.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="book-section" id="book">
          <div className="book-copy">
            <h2>Uncommon <em>Sense:</em></h2>
            <p className="book-lead">A Practical Guide to Make Earth Great Again</p>
            <p>Samuel Immanuel’s first edition brings philosophy, self-mastery, decentralisation and Earth stewardship into one provocative invitation: know yourself, question the systems around you, and act according to your truth.</p>
            <a className="button button-lime" href={content.bookUrl} target="_blank" rel="noreferrer">Find it on Lulu <ArrowUpRight /></a>
            <span className="book-meta">PRINTED IN THE UNITED STATES · ISBN 978-1-105-83279-6</span>
          </div>
          <div className="book-stage" aria-label="Uncommon Sense book cover">
            <div className="book-object">
              <div className="book-cover book-cover--photo">
                <img src="/images/uncommon-sense-cover.jpg" alt="Uncommon Sense: A Practical Guide to Make Earth Great Again — cover" />
              </div>
            </div>
            <span className="stage-caption">FIRST EDITION · 2026</span>
            <a className="button button-lime" href="/uncommon-sense.pdf" download="Uncommon Sense — 2026 Edition.pdf">Free PDF download <ArrowDown size={17} /></a>
          </div>
        </section>

        <section className="objects-section section-grid" id="objects">
          <div className="section-aside"><span>SHOP</span><span>MEGA PARTY WORLDWIDE</span></div>
          <div className="objects-content">
            <h2>Wear the ideas</h2>
            <p className="objects-intro">Shop from our collection of clothes and jewelry to show your support!</p>
            <div className="channel-list">
              <div><span>SHOPIFY</span><h3>The MEGA Party store</h3><p>The MEGA Party store offers branded clothing and handmade seashell jewelry.</p><a className="channel-status" href="https://shop.megaparty.world" target="_blank" rel="noreferrer">VISIT THE STORE — SHOP.MEGAPARTY.WORLD</a></div>
            </div>
          </div>
        </section>

        <section className="watch-section" id="watch">
          <div className="watch-copy">
            <span className="light-label">JOIN THE MEGA PARTY ON YOUTUBE & FARCASTER</span>
            <h2>{content.youtubeTitle}</h2>
            <p>Follow Samuel Immanuel as he puts the ideas presented in Uncommon Sense into practice.</p>
            <div className="watch-actions">
              <a className="button button-cream" href={content.youtubeUrl} target="_blank" rel="noreferrer">Watch on YouTube <ArrowUpRight /></a>
              <a className="button button-cream" href={content.farcasterUrl} target="_blank" rel="noreferrer">Follow on Farcaster <ArrowUpRight /></a>
            </div>
          </div>
        </section>

        <section className="updates-section" id="updates">
          <div className="updates-title"><span>FIELD NOTES</span><h2>What’s happening</h2></div>
          <div className="updates-list">
            {updatesQuery.isLoading && <p className="empty-updates">Loading the latest notes…</p>}
            {!updatesQuery.isLoading && updates.length === 0 && <p className="empty-updates">The first field note is taking root. Check back soon.</p>}
            {updates.map((update) => (
              <article key={update.id}>
                <time dateTime={update.createdAt.toISOString()}>{new Intl.DateTimeFormat("en", { month: "short", day: "2-digit", year: "numeric" }).format(update.createdAt)}</time>
                <div><h3>{update.title}</h3><p>{update.body}</p></div>
              </article>
            ))}
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-lines" aria-hidden="true"><i /><i /><i /><i /><i /></div>
        <img src="/images/mega-party-green.png" alt="MEGA Party" />
        <p>Think freely. Live consciously.<br />Make Earth great again.</p>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} MEGA PARTY.WORLD</span>
          <div><a href="#about">About</a><a href="#book">Book</a><a href="#watch">YouTube</a><a href={content.farcasterUrl} target="_blank" rel="noreferrer">Farcaster</a><Link to="/studio">Studio</Link></div>
          <a href="#top">Back to Earth ↑</a>
        </div>
      </footer>
    </div>
  );
}
