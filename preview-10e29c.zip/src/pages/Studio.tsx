import { useEffect, useState, type FormEvent } from "react";
import { ArrowLeft, ArrowUpRight, LogOut, Plus, Save, Trash2 } from "lucide-react";
import { Link } from "react-router";

type Content = {
  announcement: string;
  heroTitle: string;
  heroText: string;
  bookUrl: string;
  youtubeUrl: string;
  farcasterUrl: string;
  youtubeTitle: string;
};
type Update = { id: number; title: string; body: string; published: boolean; createdAt: string };
type Status = { needsSetup: boolean; authenticated: boolean };

async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`/api/studio${path}`, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options?.headers },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data as T;
}

export default function Studio() {
  const [status, setStatus] = useState<Status | null>(null);
  const [password, setPassword] = useState("");
  const [content, setContent] = useState<Content | null>(null);
  const [updates, setUpdates] = useState<Update[]>([]);
  const [newUpdate, setNewUpdate] = useState({ title: "", body: "", published: true });
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  const loadContent = async () => {
    const data = await api<{ content: Content; updates: Update[] }>("/content");
    setContent(data.content);
    setUpdates(data.updates);
  };

  useEffect(() => {
    api<Status>("/status").then(async (next) => {
      setStatus(next);
      if (next.authenticated) await loadContent();
    }).catch((error) => setMessage(error.message));
  }, []);

  const authenticate = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true); setMessage("");
    try {
      await api(status?.needsSetup ? "/setup" : "/login", { method: "POST", body: JSON.stringify({ password }) });
      setStatus({ needsSetup: false, authenticated: true });
      setPassword("");
      await loadContent();
      setMessage(status?.needsSetup ? "Your private Studio is ready." : "Welcome back.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to sign in."); }
    finally { setBusy(false); }
  };

  const saveContent = async (event: FormEvent) => {
    event.preventDefault();
    if (!content) return;
    setBusy(true); setMessage("");
    try {
      const data = await api<{ content: Content }>("/content", { method: "PUT", body: JSON.stringify(content) });
      setContent(data.content); setMessage("Homepage changes are live.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to save."); }
    finally { setBusy(false); }
  };

  const addUpdate = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true); setMessage("");
    try {
      const data = await api<{ updates: Update[] }>("/updates", { method: "POST", body: JSON.stringify(newUpdate) });
      setUpdates(data.updates); setNewUpdate({ title: "", body: "", published: true }); setMessage("Field note published.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to publish."); }
    finally { setBusy(false); }
  };

  const toggleUpdate = async (update: Update) => {
    setBusy(true); setMessage("");
    try {
      const data = await api<{ updates: Update[] }>(`/updates/${update.id}`, { method: "PUT", body: JSON.stringify({ ...update, published: !update.published }) });
      setUpdates(data.updates); setMessage(update.published ? "Field note moved to drafts." : "Field note published.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to update."); }
    finally { setBusy(false); }
  };

  const deleteUpdate = async (update: Update) => {
    if (!window.confirm(`Delete “${update.title}” permanently?`)) return;
    setBusy(true); setMessage("");
    try {
      const data = await api<{ updates: Update[] }>(`/updates/${update.id}`, { method: "DELETE" });
      setUpdates(data.updates); setMessage("Field note deleted.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to delete."); }
    finally { setBusy(false); }
  };

  if (!status) return <div className="studio-loading">OPENING STUDIO…</div>;

  if (!status.authenticated) {
    return (
      <main className="studio-auth">
        <Link to="/" className="studio-back"><ArrowLeft /> Back to MEGA Party</Link>
        <div className="auth-panel">
          <img src="/images/earth-mark.png" alt="MEGA Party" />
          <span>PRIVATE WEBSITE STUDIO</span>
          <h1>{status.needsSetup ? "Claim your Studio." : "Welcome back."}</h1>
          <p>{status.needsSetup ? "Create the owner password you will use to update the website. Use at least 12 characters and keep it somewhere safe." : "Enter your owner password to edit the homepage and publish field notes."}</p>
          <form onSubmit={authenticate}>
            <label htmlFor="password">Owner password</label>
            <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={12} required autoComplete={status.needsSetup ? "new-password" : "current-password"} autoFocus />
            <button className="button button-lime" type="submit" disabled={busy}>{busy ? "Opening…" : status.needsSetup ? "Create Studio access" : "Open Studio"}<ArrowUpRight /></button>
          </form>
          <p className="studio-message" aria-live="polite">{message}</p>
        </div>
      </main>
    );
  }

  return (
    <div className="studio-shell">
      <header className="studio-header">
        <div><img src="/images/earth-mark.png" alt="" /><span>MEGA PARTY / STUDIO</span></div>
        <div><Link to="/" target="_blank">View website <ArrowUpRight /></Link><button type="button" onClick={async () => { await api("/logout", { method: "POST" }); setStatus({ needsSetup: false, authenticated: false }); }}><LogOut /> Sign out</button></div>
      </header>
      <main className="studio-main">
        <div className="studio-title"><span>CONTENT DESK</span><h1>Keep the movement current.</h1><p>Changes save to the live website. No code or plugins needed.</p></div>
        <p className="studio-message" aria-live="polite">{message}</p>

        {content && <form className="editor-section" onSubmit={saveContent}>
          <div className="editor-heading"><span>01</span><div><h2>Homepage & destinations</h2><p>Update the main message or connect your Lulu, YouTube and Farcaster links.</p></div></div>
          <div className="form-grid">
            <label className="full">Announcement ribbon<input value={content.announcement} maxLength={180} onChange={(e) => setContent({ ...content, announcement: e.target.value })} required /></label>
            <label className="full">Hero headline<input value={content.heroTitle} maxLength={180} onChange={(e) => setContent({ ...content, heroTitle: e.target.value })} required /></label>
            <label className="full">Hero introduction<textarea rows={4} value={content.heroText} onChange={(e) => setContent({ ...content, heroText: e.target.value })} required /></label>
            <label>Lulu book URL<input type="url" value={content.bookUrl} onChange={(e) => setContent({ ...content, bookUrl: e.target.value })} required /></label>
            <label>YouTube URL<input type="url" value={content.youtubeUrl} onChange={(e) => setContent({ ...content, youtubeUrl: e.target.value })} required /></label>
            <label className="full">Farcaster profile URL<input type="url" value={content.farcasterUrl} onChange={(e) => setContent({ ...content, farcasterUrl: e.target.value })} required /></label>
            <label className="full">YouTube section headline<input value={content.youtubeTitle} maxLength={180} onChange={(e) => setContent({ ...content, youtubeTitle: e.target.value })} required /></label>
          </div>
          <button className="button button-lime" type="submit" disabled={busy}><Save /> Save homepage changes</button>
        </form>}

        <section className="editor-section">
          <div className="editor-heading"><span>02</span><div><h2>Publish a field note</h2><p>Share launches, new videos, company news or a thought of the day.</p></div></div>
          <form className="form-grid" onSubmit={addUpdate}>
            <label className="full">Title<input value={newUpdate.title} maxLength={180} onChange={(e) => setNewUpdate({ ...newUpdate, title: e.target.value })} required /></label>
            <label className="full">Update<textarea rows={5} value={newUpdate.body} onChange={(e) => setNewUpdate({ ...newUpdate, body: e.target.value })} required /></label>
            <label className="check-label"><input type="checkbox" checked={newUpdate.published} onChange={(e) => setNewUpdate({ ...newUpdate, published: e.target.checked })} /> Publish immediately</label>
            <button className="button button-dark" type="submit" disabled={busy}><Plus /> Add field note</button>
          </form>
        </section>

        <section className="editor-section">
          <div className="editor-heading"><span>03</span><div><h2>Your field notes</h2><p>Unpublish a note to keep it as a draft, or delete it permanently.</p></div></div>
          <div className="studio-updates">
            {updates.length === 0 && <p>No field notes yet. Publish your first one above.</p>}
            {updates.map((update) => <article key={update.id}>
              <div><span>{update.published ? "PUBLISHED" : "DRAFT"} · {new Date(update.createdAt).toLocaleDateString("en", { dateStyle: "medium" })}</span><h3>{update.title}</h3><p>{update.body}</p></div>
              <div className="update-actions"><button type="button" onClick={() => toggleUpdate(update)} disabled={busy}>{update.published ? "Unpublish" : "Publish"}</button><button className="delete-button" type="button" aria-label={`Delete ${update.title}`} onClick={() => deleteUpdate(update)} disabled={busy}><Trash2 /></button></div>
            </article>)}
          </div>
        </section>
      </main>
    </div>
  );
}
