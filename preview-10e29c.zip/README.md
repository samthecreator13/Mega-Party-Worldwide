# MEGA Party.world

Responsive brand website and private content editor for MEGA Party.

## Included

- Editorial green-logo homepage presenting the company’s values
- Uncommon Sense book feature with editable Lulu destination
- Future Shopify and Tapstitch collection introduction
- Editable YouTube destination and headline
- Persistent field notes for company news and launches
- Private `/studio` editor with first-run owner password setup
- Desktop and mobile navigation, reduced-motion support and keyboard focus states

## Run

```bash
npm install
npm run db:push
npx tsx db/seed.ts
npm run dev
```

Production:

```bash
npm run check
npm run build
npm start
```

## Editing the website

Open `/studio`. On the first visit, create an owner password of at least 12 characters. The Studio can then update homepage copy and external links, publish or unpublish field notes, and delete old notes. Content is stored in the connected database and persists across visits and website versions.

## Structure

- `src/pages/Home.tsx` — public brand website
- `src/pages/Studio.tsx` — protected content editor
- `src/index.css` — visual system and responsive layouts
- `api/routes/studio.ts` — owner authentication and editor API
- `api/contentRouter.ts` — public content API
- `db/schema.ts` — site content, field notes and session tables
- `public/images/` — supplied MEGA Party brand artwork
