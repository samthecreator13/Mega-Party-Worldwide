import { createRouter, publicQuery } from "./middleware";
import { contentRouter } from "./contentRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  content: contentRouter,
});

export type AppRouter = typeof appRouter;
