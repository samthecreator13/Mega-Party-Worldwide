import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import { deleteCookie, getCookie, setCookie } from "hono/cookie";
import { and, eq, gt } from "drizzle-orm";
import { z } from "zod";
import { admins, sessions, siteContent, updates } from "@db/schema";
import { getDb } from "../queries/connection";
import { getSiteContent, listAllUpdates } from "../queries/content";

const COOKIE_NAME = "mega_studio";
const SESSION_DAYS = 14;
const passwordSchema = z.string().min(12).max(200);
const urlSchema = z.string().url().max(500);
const contentSchema = z.object({
  announcement: z.string().trim().min(1).max(180),
  heroTitle: z.string().trim().min(1).max(180),
  heroText: z.string().trim().min(1).max(1200),
  bookUrl: urlSchema,
  youtubeUrl: urlSchema,
  farcasterUrl: urlSchema,
  youtubeTitle: z.string().trim().min(1).max(180),
});
const updateSchema = z.object({
  title: z.string().trim().min(1).max(180),
  body: z.string().trim().min(1).max(5000),
  published: z.boolean(),
});

function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}

function verifyPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const expected = Buffer.from(hash, "hex");
  const actual = scryptSync(password, salt, 64);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

async function hasAdmin() {
  const [admin] = await getDb().select({ id: admins.id }).from(admins).where(eq(admins.id, 1)).limit(1);
  return Boolean(admin);
}

async function createSession(c: Parameters<typeof setCookie>[0]) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000);
  await getDb().insert(sessions).values({ token, expiresAt });
  setCookie(c, COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "Lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_DAYS * 86400,
  });
}

async function isAuthenticated(token?: string) {
  if (!token) return false;
  const [session] = await getDb()
    .select({ token: sessions.token })
    .from(sessions)
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
    .limit(1);
  return Boolean(session);
}

export const studioRoutes = new Hono();

studioRoutes.get("/status", async (c) => {
  const authenticated = await isAuthenticated(getCookie(c, COOKIE_NAME));
  return c.json({ needsSetup: !(await hasAdmin()), authenticated });
});

studioRoutes.post("/setup", bodyLimit({ maxSize: 16 * 1024 }), async (c) => {
  if (await hasAdmin()) return c.json({ error: "Studio access is already configured." }, 409);
  const parsed = passwordSchema.safeParse((await c.req.json().catch(() => ({}))).password);
  if (!parsed.success) return c.json({ error: "Use a password of at least 12 characters." }, 400);
  await getDb().insert(admins).values({ id: 1, passwordHash: hashPassword(parsed.data) });
  await createSession(c);
  return c.json({ ok: true });
});

studioRoutes.post("/login", bodyLimit({ maxSize: 16 * 1024 }), async (c) => {
  const parsed = passwordSchema.safeParse((await c.req.json().catch(() => ({}))).password);
  if (!parsed.success) return c.json({ error: "Enter your studio password." }, 400);
  const [admin] = await getDb().select().from(admins).where(eq(admins.id, 1)).limit(1);
  if (!admin || !verifyPassword(parsed.data, admin.passwordHash)) {
    return c.json({ error: "That password is not correct." }, 401);
  }
  await createSession(c);
  return c.json({ ok: true });
});

studioRoutes.post("/logout", async (c) => {
  const token = getCookie(c, COOKIE_NAME);
  if (token) await getDb().delete(sessions).where(eq(sessions.token, token));
  deleteCookie(c, COOKIE_NAME, { path: "/" });
  return c.json({ ok: true });
});

studioRoutes.use("/content", async (c, next) => {
  if (!(await isAuthenticated(getCookie(c, COOKIE_NAME)))) return c.json({ error: "Sign in required." }, 401);
  await next();
});
studioRoutes.use("/updates", async (c, next) => {
  if (!(await isAuthenticated(getCookie(c, COOKIE_NAME)))) return c.json({ error: "Sign in required." }, 401);
  await next();
});
studioRoutes.use("/updates/*", async (c, next) => {
  if (!(await isAuthenticated(getCookie(c, COOKIE_NAME)))) return c.json({ error: "Sign in required." }, 401);
  await next();
});

studioRoutes.get("/content", async (c) => {
  return c.json({ content: await getSiteContent(), updates: await listAllUpdates() });
});

studioRoutes.put("/content", bodyLimit({ maxSize: 32 * 1024 }), async (c) => {
  const parsed = contentSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Check every field and use complete https:// links." }, 400);
  await getDb().update(siteContent).set(parsed.data).where(eq(siteContent.id, 1));
  return c.json({ content: await getSiteContent() });
});

studioRoutes.post("/updates", bodyLimit({ maxSize: 32 * 1024 }), async (c) => {
  const parsed = updateSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Add a title and update text." }, 400);
  await getDb().insert(updates).values(parsed.data);
  return c.json({ updates: await listAllUpdates() }, 201);
});

studioRoutes.put("/updates/:id", bodyLimit({ maxSize: 32 * 1024 }), async (c) => {
  const id = Number(c.req.param("id"));
  if (!Number.isInteger(id)) return c.json({ error: "Invalid update." }, 400);
  const parsed = updateSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: "Check the update fields." }, 400);
  await getDb().update(updates).set(parsed.data).where(eq(updates.id, id));
  return c.json({ updates: await listAllUpdates() });
});

studioRoutes.delete("/updates/:id", async (c) => {
  const id = Number(c.req.param("id"));
  if (!Number.isInteger(id)) return c.json({ error: "Invalid update." }, 400);
  await getDb().delete(updates).where(eq(updates.id, id));
  return c.json({ updates: await listAllUpdates() });
});
