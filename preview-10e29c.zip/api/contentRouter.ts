import { createRouter, publicQuery } from "./middleware";
import { getSiteContent, listPublishedUpdates } from "./queries/content";

export const contentRouter = createRouter({
  site: publicQuery.query(() => getSiteContent()),
  updates: publicQuery.query(() => listPublishedUpdates()),
});
