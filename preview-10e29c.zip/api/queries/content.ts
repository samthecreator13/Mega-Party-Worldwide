import { desc, eq } from "drizzle-orm";
import { siteContent, updates } from "@db/schema";
import { getDb } from "./connection";

export const defaultContent = {
  id: 1,
  announcement: "Ideas for Earth. Objects for the movement.",
  heroTitle: "Make Earth great again",
  heroText:
    "MEGA Party Worldwide is an independent ideas house for truth seekers and independent thinkers. We promote free speech and open discussions to solve the problems of our complex world. Our mission is to awaken the divinity within each of our community members so they may reclaim their power to shape our world. We promote the African philosophy of Ubuntu, meaning “I am because we are,” and the harmonious principle of Ma’at.",
  bookUrl: "https://www.lulu.com/shop/samuel-immanuel/uncommon-sense/paperback/product-456n9r6.html?q=uncommon+sense&page=1&pageSize=4",
  youtubeUrl: "https://www.youtube.com/@samuelimmanuel13",
  farcasterUrl: "https://farcaster.xyz/samuelimmanuel",
  youtubeTitle: "Watch the ideas in motion",
};

export async function getSiteContent() {
  const db = getDb();
  const [content] = await db.select().from(siteContent).where(eq(siteContent.id, 1)).limit(1);
  if (content) {
    // One-time migration: replace the original default hero copy with the updated mission statement
    if (content.heroTitle === "Make Earth great again.") {
      await db
        .update(siteContent)
        .set({ heroTitle: defaultContent.heroTitle, heroText: defaultContent.heroText })
        .where(eq(siteContent.id, 1));
      return { ...content, heroTitle: defaultContent.heroTitle, heroText: defaultContent.heroText };
    }
    return content;
  }
  await db.insert(siteContent).values(defaultContent).onDuplicateKeyUpdate({ set: { id: 1 } });
  const [created] = await db.select().from(siteContent).where(eq(siteContent.id, 1)).limit(1);
  return created;
}

export async function listPublishedUpdates() {
  return getDb()
    .select()
    .from(updates)
    .where(eq(updates.published, true))
    .orderBy(desc(updates.createdAt))
    .limit(12);
}

export async function listAllUpdates() {
  return getDb().select().from(updates).orderBy(desc(updates.createdAt)).limit(100);
}
