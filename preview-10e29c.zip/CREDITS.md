# Asset credits

- MEGA Party green logo and derived Earth mark: supplied by the website owner.
- Uncommon Sense title, author and publication details: supplied from the owner’s 2026 manuscript.
- Barlow Condensed and IBM Plex Mono: distributed through Google Fonts under the SIL Open Font License.
- Interface icons: Lucide, ISC License.
