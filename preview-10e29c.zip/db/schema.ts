import {
  boolean,
  int,
  mysqlTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const siteContent = mysqlTable("site_content", {
  id: int("id").primaryKey(),
  announcement: varchar("announcement", { length: 180 }).notNull(),
  heroTitle: varchar("hero_title", { length: 180 }).notNull(),
  heroText: text("hero_text").notNull(),
  bookUrl: varchar("book_url", { length: 500 }).notNull(),
  youtubeUrl: varchar("youtube_url", { length: 500 }).notNull(),
  farcasterUrl: varchar("farcaster_url", { length: 500 }).default("").notNull(),
  youtubeTitle: varchar("youtube_title", { length: 180 }).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const updates = mysqlTable("updates", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  body: text("body").notNull(),
  published: boolean("published").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const admins = mysqlTable("admins", {
  id: int("id").primaryKey(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sessions = mysqlTable("sessions", {
  token: varchar("token", { length: 64 }).primaryKey(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
