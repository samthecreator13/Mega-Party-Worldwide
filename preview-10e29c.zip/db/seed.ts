import { getDb } from "../api/queries/connection";
import { getSiteContent } from "../api/queries/content";
import { updates } from "./schema";

async function seed() {
  const db = getDb();
  await getSiteContent();
  const existing = await db.select({ id: updates.id }).from(updates).limit(1);
  if (existing.length === 0) {
    await db.insert(updates).values({
      title: "The MEGA Party begins here",
      body: "Our new digital home is taking root: Uncommon Sense, original ideas and purposeful objects in one place. Follow the journey as the movement grows.",
      published: true,
    });
  }
  console.log("MEGA Party content seeded.");
  process.exit(0);
}

seed().catch((error) => {
  console.error(error);
  process.exit(1);
});
